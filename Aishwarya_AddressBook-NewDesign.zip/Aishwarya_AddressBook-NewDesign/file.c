#include <stdio.h>
#include "file.h"

void saveContactsToFile(AddressBook *addressBook) 
{
    FILE *fptr = fopen("contacts.csv", "w");
    if(fptr == NULL)
    {
        perror("File open failed\n");
        return;
    }

    // Save the number of contacts
    fprintf(fptr,"%d\n",addressBook->contactCount);
    //Loop to save all contacts to file

    for(int i=0; i < addressBook -> contactCount; i++)
    {
        fprintf(fptr,"%s,%s,%s\n",
        addressBook->contacts[i].name,
        addressBook->contacts[i].phone,
        addressBook->contacts[i].email);
    }
    fclose(fptr);
}

void loadContactsFromFile(AddressBook *addressBook) 
{  
    //Initialize count to 0 before loading.
   // addressBook->contactCount=0;
    FILE *fptr = fopen("contacts.csv", "r");//Opens file in the read mode

    if(fptr == NULL)
    {
        perror("File open failed\n");
        return;
    }

   // char buffer[50];//buffer to store first line of file
    fscanf(fptr,"%d\n",&addressBook->contactCount);

    // Read all contacts
    for(int i=0; i < addressBook -> contactCount; i++)
    {
        fscanf(fptr,"%[^,],%[^,],%[^\n]\n",
        addressBook->contacts[i].name,
        addressBook->contacts[i].phone,
        addressBook->contacts[i].email);
    }

    fclose(fptr);

    printf("Loaded contacts : %d\n",addressBook->contactCount);
    
}
